function nccScore = computeNCC(img1, img2)
    % Convert to grayscale if needed
    if size(img1, 3) == 3
        img1 = rgb2gray(img1);
    end
    if size(img2, 3) == 3
        img2 = rgb2gray(img2);
    end

    % Resize both to same size (or choose your own policy)
    img1 = im2double(imresize(img1, size(img2)));
    img2 = im2double(imresize(img2, size(img1)));

    % Subtract means
    img1 = img1 - mean(img1(:));
    img2 = img2 - mean(img2(:));

    % Compute normalized cross-correlation
    numerator = sum(sum(img1 .* img2));
    denominator = sqrt(sum(sum(img1 .^ 2)) * sum(sum(img2 .^ 2)));

    nccScore = numerator / denominator;
end
