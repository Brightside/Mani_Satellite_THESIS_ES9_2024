function rotated_image = rotate_image(input_image, angle_degrees)
% ROTATE_IMAGE Rotates an input image (matrix) by a specified angle.
%
%   rotated_image = ROTATE_IMAGE(input_image, angle_degrees)
%
%   INPUTS:
%       input_image   - A 2D matrix representing the image.
%       angle_degrees - The rotation angle in degrees (counter-clockwise).
%
%   OUTPUTS:
%       rotated_image - The rotated image (matrix).

    % Convert angle from degrees to radians
    angle_radians = deg2rad(angle_degrees);

    % Create the 2D rotation matrix
    rotation_matrix = [cos(angle_radians), -sin(angle_radians);
                       sin(angle_radians),  cos(angle_radians)];

    % Get the dimensions of the input image
    [rows, cols] = size(input_image);

    % Initialize the rotated image matrix (you might need to adjust the size
    % depending on how you want to handle image boundaries after rotation)
    rotated_rows = ceil(rows * abs(cos(angle_radians)) + cols * abs(sin(angle_radians)));
    rotated_cols = ceil(rows * abs(sin(angle_radians)) + cols * abs(cos(angle_radians)));
    rotated_image = zeros(rotated_rows, rotated_cols);

    % Calculate the center of the original image
    center_row = (rows + 1) / 2;
    center_col = (cols + 1) / 2;

    % Calculate the center of the rotated image
    rotated_center_row = (rotated_rows + 1) / 2;
    rotated_center_col = (rotated_cols + 1) / 2;

    % Iterate through each pixel of the rotated image
    for i = 1:rotated_rows
        for j = 1:rotated_cols
            % Calculate the corresponding coordinates in the original image
            x = j - rotated_center_col;
            y = i - rotated_center_row;

            % Apply the inverse rotation to find the original coordinates
            original_coords = rotation_matrix' * [x; y];
            original_col = round(original_coords(1) + center_col);
            original_row = round(original_coords(2) + center_row);

            % Check if the original coordinates are within the bounds of the
            % input image
            if (original_row >= 1 && original_row <= rows && ...
                original_col >= 1 && original_col <= cols)
                rotated_image(i, j) = input_image(original_row, original_col);
            end
        end
    end
end