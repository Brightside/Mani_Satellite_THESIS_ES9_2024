%Attempting the comparison tools.
clc, clear

% Load images and convert to grayscale if necessary
img_ref = imread('test_images\A17_topdown_trim.png'); 
img_oblique = imread('test_images\A17_oblique_trim.png'); 


if size(img_ref,3) == 3
    img_ref = rgb2gray(img_ref);
end
if size(img_oblique,3) == 3
    img_oblique = rgb2gray(img_oblique);
end

% Trim images of padding (trial & error)
ref_trimming_factor_col = 3;
ref_trimming_factor_row = 3;
oblique_trimming_factor_col = 4;
oblique_trimming_factor_row = 3;

img_ref = img_ref(ref_trimming_factor_row:(end-ref_trimming_factor_row),ref_trimming_factor_col:(end-ref_trimming_factor_col));
img_oblique = img_oblique(oblique_trimming_factor_row:(end-oblique_trimming_factor_row),oblique_trimming_factor_col:(end-oblique_trimming_factor_col));

img_ref_eq = adapthisteq(img_ref);
img_oblique_eq = adapthisteq(img_oblique);

rng(1)

% Binarize using Otsu's thresholding
bw_ref = ~imbinarize(img_ref, 0.4);    %for known ref
bw_oblique = ~imbinarize(img_oblique, 0.1);

% Remove small objects (adjust threshold as needed)
bw_ref = bwareaopen(bw_ref, 20);            % A17   Removes all areas containing <x pixels (20)
bw_oblique = bwareaopen(bw_oblique, 120);    % A17   

% OPTIONAL: Overlay filtered binary image onto original
overlay_ref = imoverlay(img_ref, bw_ref, [1 0 0]); 
overlay_oblique = imoverlay(img_oblique, bw_oblique, [0 0 1]);

% Detect SIFT features on binary images
points_ref = detectSIFTFeatures(bw_ref);
points_oblique = detectSIFTFeatures(bw_oblique);

%Filter for the N strongest, N being defined
NumKeypoints = 200;
points_ref = selectStrongest(points_ref,NumKeypoints);
points_oblique = selectStrongest(points_oblique,NumKeypoints);

[features_ref, valid_points_ref] = extractFeatures(bw_ref, points_ref);
[features_oblique, valid_points_oblique] = extractFeatures(bw_oblique, points_oblique);

% Match features
indexPairs = matchFeatures(features_ref, features_oblique, 'MaxRatio', 0.6, 'MatchThreshold', 30);

% Check if we have enough matches
if isempty(indexPairs) || size(indexPairs,1) < 4
    error("Not enough feature matches. Try adjusting preprocessing or parameters.");
end

% Get matched points
matchedPoints_ref = valid_points_ref(indexPairs(:,1));
matchedPoints_oblique = valid_points_oblique(indexPairs(:,2));

% Compute transformation matrix from binary images
[tform_test, inlierIdx] = estimateGeometricTransform2D(...
    matchedPoints_oblique, matchedPoints_ref, 'projective', 'MaxNumTrials', 5000);

% Validate transformation matrix
if cond(tform_test.T) > 1e6  
    warning("Transformation is nearly singular. Switching to affine model.");
    [tform, inlierIdx] = estimateGeometricTransform2D(...
        matchedPoints_oblique, matchedPoints_ref, 'affine', 'MaxNumTrials', 5000);
end

% Apply transformation to original oblique image
warped_img = imwarp(img_oblique, tform, 'OutputView',imref2d(size(img_ref)));                                            
warped_img = flip(warped_img,2);

%remove all empty rows and coloumns containing ONLY zeros, essentially trimming
warped_img = warped_img(any(warped_img,2),:);
warped_img = warped_img(:, any(warped_img,1));

resized_warped_img = imresize(warped_img,size(img_ref));

%Show images:
%size(resized_warped_img_test)
%size(img_ref)
% montage({img_oblique,img_ref,resized_warped_img},Size = [1 NaN], BackgroundColor="black")
figure(1);
showMatchedFeatures(img_ref,img_oblique,matchedPoints_ref,matchedPoints_oblique,"montage");
figure(2);
imshow(resized_warped_img)

imwrite(resized_warped_img,"Resulting_Transform_SIFT.png")
%% Various comparison tools
clc
%index:
% load image
% Normalization step of images
% Surf based feature match
% HOG comparison
% Read images

rng(1); %Set the stream to static path, to ensure repeatability

Original_inputImage = resized_warped_img;
%referenceImage = img_ref;
referenceImage = medfilt2(img_ref, [1 1]*1);  % Median filter (3x3 kernel)

% binarize mask
bw_Input    = ~imbinarize(Original_inputImage,0.35);
bw_ref      = ~imbinarize(referenceImage,0.7);

% filter small objects to isolate wedges. use invert bw_Input to get actual mask
bw_Wedges = imbinarize(Original_inputImage,0.1);
bw_Filter_Input = bwareaopen(~bw_Wedges,500);

% overlay mask, first compute mean pixel intensity of contained area
meanIn  = mean(Original_inputImage(Original_inputImage>1));
% inputImage  = imoverlay(Original_inputImage,bw_Filter_Input,[1,1,1]*(meanIn/255));
% inputImage  = im2gray(inputImage);

inputImage = Original_inputImage;



% ----------------------------------------------------------------------------------------------------------------------
% Normalization of images to match global intensity
meanIn  = mean(Original_inputImage(Original_inputImage>1)); 
meanRef = mean(referenceImage(:));

intensityDiff = meanIn-meanRef;

% % adjust global difference
% inputImage = inputImage-intensityDiff;
% 
% newWedge = mean(inputImage(inputImage>(intensityDiff+1)));
% % Adjust if pixel values goes outside range
% inputImage(inputImage < (abs(intensityDiff) +2)) = 1;
% inputImage(inputImage > 255) = 255;

%Ensure same datatype as previously
%inputImage = cast(inputImage,class(resized_warped_img));

%check
imshow(inputImage)
%montage({img_ref,inputImage},size = [1,NaN],BackgroundColor='white',BorderSize=10)
%% ----------------------------------------------------------------------------------------------------------------------
% Feature matching using SURF
numKeypoints = 20;  % Fixed number of strongest points to keep

inputPoints = detectSURFFeatures(inputImage);
referencePoints = detectSURFFeatures(referenceImage);
% inputPoints = detectSIFTFeatures(inputImage);
% referencePoints = detectSIFTFeatures(referenceImage);

% Select the strongest N keypoints
inputPoints = selectStrongest(inputPoints, numKeypoints);
referencePoints = selectStrongest(referencePoints, numKeypoints);

% Extract features & Match features
[inputFeatures, inputValidPoints] = extractFeatures(inputImage, inputPoints);
[referenceFeatures, referenceValidPoints] = extractFeatures(referenceImage, referencePoints);
indexPairs = matchFeatures(inputFeatures, referenceFeatures, 'MatchThreshold', 20, 'MaxRatio',1, 'Unique',true);

matchedPointsInput = inputValidPoints(indexPairs(:, 1), :);
matchedPointsReference = referenceValidPoints(indexPairs(:, 2), :);

[tform, inlierIdx] = estgeotform2d(matchedPointsInput, matchedPointsReference, 'projective', ...
    'MaxNumTrials', 1000, 'Confidence', 99.5);

inlierMatches = sum(inlierIdx);
totalKeypoints = size(referenceValidPoints, 1);

% Compute adjusted match score          0.7 -> 70%
featureMatchScore = inlierMatches / totalKeypoints

showMatchedFeatures(referenceImage,inputImage,matchedPointsReference,matchedPointsInput,"montage")

%% Compute SSIM between aligned input and reference image  - Check later. yields 0.2580 (check gpt or gemini)
%Filter the binary masks for small objects
inv_bw_Input    = bwareaopen(~bw_Input,200);
inv_bw_ref      = bwareaopen(~bw_ref,200);
bw_Input = inv_bw_Input;
bw_ref = inv_bw_ref;
%intersect regions
commonMask = ~bw_Input & ~bw_ref;

bw_Input_ssim    = cast(bw_Input,class(Original_inputImage));
bw_ref_ssim      = cast(bw_ref,class(img_ref));

[notused,ssimMap] = ssim(bw_Input_ssim,bw_ref_ssim); %disregard numerical value, compute it using mask instead
ssimScore = mean(ssimMap(~commonMask));

imshowpair(bw_Input_ssim,bw_ref_ssim,'montage')
%montage({bw_Input_ssim,bw_ref_ssim,ssimMap})
%% Mutual information (See functions)

% Mutual Information
totalBins = 100;
mi = computeMutualInformation(inputImage, referenceImage,totalBins)
nmi = computeNormalizedMutualInformation(inputImage,referenceImage, totalBins)


%% Normalized Cross-Correlation (NCC) (NOT USED)
nccScore = computeNCC(inputImage,referenceImage)


%% Scoring for all tools
clc
method_string = ["SURF","SSIM","Mutual Info","NMI"];
method_Score = [featureMatchScore,ssimScore,mi,nmi];

score_board = [method_string;method_Score]


%Weighted score, not used. 
weight_SURF = 30; % percent
weight_SSIM = 40;
weight_MI   = 30; 
MeanScore = (weight_SURF/100)*featureMatchScore + (weight_SSIM/100)*ssimScore + (weight_MI/100)*nmi;

fprintf("Average score: %.2f", MeanScore)
%% Overlaying a mask showing points. 
% for report to showcase lines between reference points and warp-points
bw_warp = resized_warped_img > 1;
bw_warp_inv = ~bw_warp;

CC = bwconncomp(bw_warp_inv);

filledBlackAreas = bw_warp_inv;
for i = 1:CC.NumObjects
    pixelList = CC.PixelIdxList{i};
    [r,c] = ind2sub(size(bw_warp_inv), pixelList);

    %Check if any pixels touch border
    if any(r == 1) || any(r == size(bw_warp_inv,1)) || ...
       any(c == 1) || any(c == size(bw_warp_inv,2))
        filledBlackAreas(pixelList) = false;    %mark for filling
    end
end

test = imoverlay(resized_warped_img,filledBlackAreas,[1,0,0]);

% Display overlay images
figure(1); imshow(overlay_ref); %title('Reference with Binary Overlay');
figure(2); imshow(overlay_oblique); %title('Oblique with Binary Overlay');
figure(3); imshow(resized_warped_img); %title('Warped Image (Using Binary Transform)');

figure(4);imshow(test)
