function nmi = computeNormalizedMutualInformation(img1, img2, numBins)
    % Check if numBins is a positive integer
    if ~isscalar(numBins) || numBins <= 0 || floor(numBins) ~= numBins
        error('numBins must be a positive scalar integer.');
    end

    % Get original image properties and preprocess
    if size(img1, 3) == 3, img1 = rgb2gray(img1); end
    if size(img2, 3) == 3, img2 = rgb2gray(img2); end
    if ~isequal(size(img1), size(img2)), img1 = imresize(img1, size(img2)); img2 = imresize(img2, size(img1)); end

    % Determine bin edges
    minVal = double(min(img1(:)));
    maxVal = double(max(img1(:)));
    binEdges = linspace(minVal, maxVal, double(numBins + 1));

    % Compute histograms
    hist1 = histcounts(img1(:), binEdges);
    hist2 = histcounts(img2(:), binEdges);
    jointHist = histcounts2(img1(:), img2(:), binEdges, binEdges);

    % Convert histograms to probabilities, handling potential zeros
    prob1 = hist1 / sum(hist1) + eps; % Add a small epsilon for numerical stability
    prob2 = hist2 / sum(hist2) + eps;
    jointProb = jointHist / sum(jointHist(:)) + eps;

    % Compute entropies
    entropy1 = -sum(prob1 .* log2(prob1));
    entropy2 = -sum(prob2 .* log2(prob2));
    jointEntropy = -sum(jointProb(jointProb > 0) .* log2(jointProb(jointProb > 0)));

    % Compute Mutual Information
    mi = entropy1 + entropy2 - jointEntropy;

    % Calculate Normalized Mutual Information (using the standard formula)
    nmi = 2 * mi / (entropy1 + entropy2);
end