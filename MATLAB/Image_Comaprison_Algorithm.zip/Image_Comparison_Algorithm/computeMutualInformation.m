function mi = computeMutualInformation(img1, img2, numBins)
% Check if numBins is a positive integer
    if ~isscalar(numBins) || numBins <= 0 || floor(numBins) ~= numBins
        error('numBins must be a positive scalar integer.');
    end

    % Get original image properties
    dataType1 = class(img1);
    dataType2 = class(img2);
    size1 = size(img1);
    size2 = size(img2);

    % Convert to grayscale if needed (and store the information)
    isColor1 = (ndims(img1) == 3);
    isColor2 = (ndims(img2) == 3);
    if isColor1
        img1_gray = rgb2gray(img1);
    else
        img1_gray = img1;
    end
    if isColor2
        img2_gray = rgb2gray(img2);
    else
        img2_gray = img2;
    end

    % Resize to same dimensions (keeping the potentially different sizes in mind)
    if ~isequal(size1(1:2), size2(1:2))
        img1_resized = imresize(img1_gray, size(img2_gray));
        img2_resized = imresize(img2_gray, size(img1_gray));
    else
        img1_resized = img1_gray;
        img2_resized = img2_gray;
    end

    % Determine bin edges based on the specified numBins
    minVal = double(min(img1_resized(:)));
    maxVal = double(max(img1_resized(:)));
    binEdges = linspace(minVal, maxVal, double(numBins + 1));

    % Compute joint histogram
    jointHist = histcounts2(img1_resized(:), img2_resized(:), binEdges, binEdges);
    jointProb = jointHist / sum(jointHist(:));

    % Marginal probabilities
    p1 = sum(jointProb, 2);  % img1
    p2 = sum(jointProb, 1);  % img2

    % Mask to avoid log(0)
    [P1, P2] = meshgrid(p2, p1);
    mask = jointProb > 0;

    % Compute mutual information
    mi = sum(jointProb(mask) .* log2(jointProb(mask) ./ (P1(mask) .* P2(mask))));
end