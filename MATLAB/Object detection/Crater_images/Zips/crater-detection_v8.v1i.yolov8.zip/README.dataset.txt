# crater-detection_v8 > 2025-05-31 2:56pm
https://universe.roboflow.com/svmtesting/crater-detection_v8-ryezj

Provided by a Roboflow user
License: CC BY 4.0

